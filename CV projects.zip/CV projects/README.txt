Highly Recommend you to view projects via below links.

Superstore Discounted Sales Analysis:
https://public.tableau.com/views/SalesStoryfinal/SalesStory?:language=en-US&publish=yes&:display_count=n&:origin=viz_share_link

Developers Survey Analysis:
https://public.tableau.com/views/Techstory/Story?:language=en-US&publish=yes&:display_count=n&:origin=viz_share_link

Sydney Property Analysis:
https://public.tableau.com/views/SYD_PROfinal/Story?:language=en-US&publish=yes&:display_count=n&:origin=viz_share_link

CommonLit Readability Prize (Kaggle Data Science Competition Silver Medal):
https://www.kaggle.com/joechan619/svm-stacking-88th                                                                                                                                     